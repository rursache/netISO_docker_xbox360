What is connectx?
 
Connectx is a plugin for Freestyle Dash 2.2 that will allow you to boot/play games off of
samba shares on a remote PC via network.
 
How to use:
First you must aquire connectx.xex from a devkit unit flash. (Version must be 2.0.20353.0)
*Due to legal reasons we can not provide you this file, please do not ask us for it.
 
Then you will need to apply the included patch (connectx_patch.xexp in the \Freestle Dash\Plugins folder of FSD) to the connectx.xex using Xextool 6.3
 
To do this use the following command:
xextool -p connectx_patch.xexp connectx.xex
 
(This will overwrite the orginal unpatched connectx.xex file so make a backup first.)
 
Afterwards, placed the patched conectx.xex in the \Freestle Dash\Plugins folder.
and cold reboot your Xbox 360.
 
Next go to the Settings menu -> System settings -> Plugins.
It should say Connectx Plugin is Loaded.
 
Then, enter your share information and username password.
Your shares need to be standard windows/samba shares.
 
Next, cold reboot your Xbox 360 again.
 
Once you have done that you should now see ConX: in filemanger.
 
Now you can manage files from the ConX: share via filemanager or add a path via path manager like you normally would for a local device.
 
The games will then appear in your game list like any other, and will be playable just like it was being loaded off
of USB/HDD.
 
Please keep in mind though the load times will likely be higher based on your network's performance.